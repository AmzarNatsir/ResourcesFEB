<?php 
defined('BASEPATH') OR exit ('No direct script access allowed');
/**
 * 
 */
class Opsi extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model(array('Model_opsi_sikap', 'Model_opsi_pengetahuan', 'Model_opsi_keterampilan_umum', 'Model_opsi_keterampilan_khusus', 'Model_opsi_kat_faq', 'Model_opsi_kat_berita'));
		date_default_timezone_set("Asia/Makassar");
	}
	private $_path_opsi_sikap = "opsi/aspek_sikap/";
	private $_path_opsi_pengetahuan = "opsi/aspek_pengetahuan/";
	private $_path_opsi_keterampilan_umum = "opsi/keterampilan_umum/";
	private $_path_opsi_keterampilan_khusus = "opsi/keterampilan_khusus/";
	private $_path_opsi_kat_faq = "opsi/kategori_faq/";
	private $_path_opsi_kat_berita = "opsi/kategori_berita/";
	function _init()
	{
		$this->output->set_template('index');
	}
	//aspek sikap
	function aspek_sikap()
	{
		$this->Model_security->get_security();
		$this->_init();
		$data['list_data'] = $this->Model_opsi_sikap->get_all();
		$data['nom_urut'] = $this->Model_opsi_sikap->get_no_urut();
		$this->load->view($this->_path_opsi_sikap."index", $data);
	}
	function aspek_sikap_simpan()
	{
		$this->Model_security->get_security();
		$data['no_urut'] = $this->input->post("nomor_urut");
		$data['aspek_sikap'] = $this->input->post("nm_aspek_sikap");
		$this->Model_opsi_sikap->insert_data($data);
		$this->session->set_flashdata("konfirm", "Data berhasil disimpan");
		redirect("opsi/aspek_sikap");
	}
	function aspek_sikap_edit()
	{
		$this->Model_security->get_security();
		$id_tabel = $this->uri->segment(3);
		$data['res'] = $this->Model_opsi_sikap->get_profil($id_tabel);
		$this->load->view($this->_path_opsi_sikap."edit", $data);
	}
	function aspek_sikap_rubah()
	{
		$this->Model_security->get_security();
		$id_tabel = $this->input->post('id_tabel');
		$data['aspek_sikap'] = $this->input->post("nm_aspek_sikap");
		$this->Model_opsi_sikap->update_data($id_tabel, $data);
		$this->session->set_flashdata("konfirm", "Perubahan data berhasil disimpan");
		redirect("opsi/aspek_sikap");
	}
	function aspek_sikap_hapus()
	{
		$this->Model_security->get_security();
		$id_tabel = $this->input->post('id_data');
		$this->Model_opsi_sikap->delete_data($id_tabel);
		echo "Data berhasil di hapus";
	}
	//aspek pengetahuan
	function aspek_pengetahuan()
	{
		$this->Model_security->get_security();
		$this->_init();
		$data['list_data'] = $this->Model_opsi_pengetahuan->get_all();
		$data['nom_urut'] = $this->Model_opsi_pengetahuan->get_no_urut();
		$this->load->view($this->_path_opsi_pengetahuan."index", $data);
	}
	function aspek_pengetahuan_simpan()
	{
		$this->Model_security->get_security();
		$data['no_urut'] = $this->input->post("nomor_urut");
		$data['aspek_pengetahuan'] = $this->input->post("nm_aspek_pengetahuan");
		$this->Model_opsi_pengetahuan->insert_data($data);
		$this->session->set_flashdata("konfirm", "Data berhasil disimpan");
		redirect("opsi/aspek_pengetahuan");
	}
	function aspek_pengetahuan_edit()
	{
		$this->Model_security->get_security();
		$id_tabel = $this->uri->segment(3);
		$data['res'] = $this->Model_opsi_pengetahuan->get_profil($id_tabel);
		$this->load->view($this->_path_opsi_pengetahuan."edit", $data);
	}
	function aspek_pengetahuan_rubah()
	{
		$this->Model_security->get_security();
		$id_tabel = $this->input->post('id_tabel');
		$data['aspek_pengetahuan'] = $this->input->post("nm_aspek_pengetahuan");
		$this->Model_opsi_pengetahuan->update_data($id_tabel, $data);
		$this->session->set_flashdata("konfirm", "Perubahan data berhasil disimpan");
		redirect("opsi/aspek_pengetahuan");
	}
	function aspek_pengetahuan_hapus()
	{
		$this->Model_security->get_security();
		$id_tabel = $this->input->post('id_data');
		$this->Model_opsi_pengetahuan->delete_data($id_tabel);
		echo "Data berhasil di hapus";
	}
	//aspek keterampilan umum
	function keterampilan_umum()
	{
		$this->Model_security->get_security();
		$this->_init();
		$data['list_data'] = $this->Model_opsi_keterampilan_umum->get_all();
		$data['nom_urut'] = $this->Model_opsi_keterampilan_umum->get_no_urut();
		$this->load->view($this->_path_opsi_keterampilan_umum."index", $data);
	}
	function keterampilan_umum_simpan()
	{
		$this->Model_security->get_security();
		$data['no_urut'] = $this->input->post("nomor_urut");
		$data['keterampilan_umum'] = $this->input->post("nm_aspek_ku");
		$this->Model_opsi_keterampilan_umum->insert_data($data);
		$this->session->set_flashdata("konfirm", "Data berhasil disimpan");
		redirect("opsi/keterampilan_umum");
	}
	function keterampilan_umum_edit()
	{
		$this->Model_security->get_security();
		$id_tabel = $this->uri->segment(3);
		$data['res'] = $this->Model_opsi_keterampilan_umum->get_profil($id_tabel);
		$this->load->view($this->_path_opsi_keterampilan_umum."edit", $data);
	}
	function keterampilan_umum_rubah()
	{
		$this->Model_security->get_security();
		$id_tabel = $this->input->post('id_tabel');
		$data['keterampilan_umum'] = $this->input->post("nm_aspek_ku");
		$this->Model_opsi_keterampilan_umum->update_data($id_tabel, $data);
		$this->session->set_flashdata("konfirm", "Perubahan data berhasil disimpan");
		redirect("opsi/keterampilan_umum");
	}
	function keterampilan_umum_hapus()
	{
		$this->Model_security->get_security();
		$id_tabel = $this->input->post('id_data');
		$this->Model_opsi_keterampilan_umum->delete_data($id_tabel);
		echo "Data berhasil di hapus";
	}
	//aspek keterampilan khusus
	function keterampilan_khusus()
	{
		$this->Model_security->get_security();
		$this->_init();
		$data['list_data'] = $this->Model_opsi_keterampilan_khusus->get_all();
		$data['nom_urut'] = $this->Model_opsi_keterampilan_khusus->get_no_urut();
		$this->load->view($this->_path_opsi_keterampilan_khusus."index", $data);
	}
	function keterampilan_khusus_simpan()
	{
		$this->Model_security->get_security();
		$data['no_urut'] = $this->input->post("nomor_urut");
		$data['keterampilan_khusus'] = $this->input->post("nm_aspek_kk");
		$this->Model_opsi_keterampilan_khusus->insert_data($data);
		$this->session->set_flashdata("konfirm", "Data berhasil disimpan");
		redirect("opsi/keterampilan_khusus");
	}
	function keterampilan_khusus_edit()
	{
		$this->Model_security->get_security();
		$id_tabel = $this->uri->segment(3);
		$data['res'] = $this->Model_opsi_keterampilan_khusus->get_profil($id_tabel);
		$this->load->view($this->_path_opsi_keterampilan_khusus."edit", $data);
	}
	function keterampilan_khusus_rubah()
	{
		$this->Model_security->get_security();
		$id_tabel = $this->input->post('id_tabel');
		$data['keterampilan_khusus'] = $this->input->post("nm_aspek_kk");
		$this->Model_opsi_keterampilan_khusus->update_data($id_tabel, $data);
		$this->session->set_flashdata("konfirm", "Perubahan data berhasil disimpan");
		redirect("opsi/keterampilan_khusus");
	}
	function keterampilan_khusus_hapus()
	{
		$this->Model_security->get_security();
		$id_tabel = $this->input->post('id_data');
		$this->Model_opsi_keterampilan_khusus->delete_data($id_tabel);
		echo "Data berhasil di hapus";
	}
	//kategori faq
	public function kategori_faq()
	{
		$this->Model_security->get_security();
		$this->_init();
		$data['list_data'] = $this->Model_opsi_kat_faq->get_all();
		$this->load->view($this->_path_opsi_kat_faq."index", $data);
	}
	public function kategori_faq_simpan()
	{
		$this->Model_security->get_security();
		$data['nm_kat_faq'] = $this->input->post("nm_kategori");
		$this->Model_opsi_kat_faq->insert_data($data);
		$this->session->set_flashdata("konfirm", "Data berhasil disimpan");
		redirect("opsi/kategori_faq");
	}
	public function kategori_faq_edit()
	{
		$this->Model_security->get_security();
		$id_tabel = $this->uri->segment(3);
		$data['res'] = $this->Model_opsi_kat_faq->get_profil($id_tabel);
		$this->load->view($this->_path_opsi_kat_faq."edit", $data);
	}
	public function kategori_faq_rubah()
	{
		$this->Model_security->get_security();
		$id_tabel = $this->input->post('id_tabel');
		$data['nm_kat_faq'] = $this->input->post("nm_kategori");
		$this->Model_opsi_kat_faq->update_data($id_tabel, $data);
		$this->session->set_flashdata("konfirm", "Perubahan data berhasil disimpan");
		redirect("opsi/kategori_faq");
	}
	function kategori_faq_hapus()
	{
		$this->Model_security->get_security();
		$id_tabel = $this->input->post('id_data');
		$this->Model_opsi_kat_faq->delete_data($id_tabel);
		echo "Data berhasil di hapus";
	}
	//kategori berita
	
	public function kategori_berita()
	{
		$this->Model_security->get_security();
		$this->_init();
		$data['list_data'] = $this->Model_opsi_kat_berita->get_all();
		$this->load->view($this->_path_opsi_kat_berita."index", $data);
	}
	public function kategori_berita_simpan()
	{
		$this->Model_security->get_security();
		$data['nm_kategori'] = $this->input->post("nm_kategori");
		$this->Model_opsi_kat_berita->insert_data($data);
		$this->session->set_flashdata("konfirm", "Data berhasil disimpan");
		redirect("opsi/kategori_berita");
	}
	public function kategori_berita_edit()
	{
		$this->Model_security->get_security();
		$id_tabel = $this->uri->segment(3);
		$data['res'] = $this->Model_opsi_kat_berita->get_profil($id_tabel);
		$this->load->view($this->_path_opsi_kat_berita."edit", $data);
	}
	public function kategori_berita_rubah()
	{
		$this->Model_security->get_security();
		$id_tabel = $this->input->post('id_tabel');
		$data['nm_kategori'] = $this->input->post("nm_kategori");
		$this->Model_opsi_kat_berita->update_data($id_tabel, $data);
		$this->session->set_flashdata("konfirm", "Perubahan data berhasil disimpan");
		redirect("opsi/kategori_berita");
	}
	function kategori_berita_hapus()
	{
		$this->Model_security->get_security();
		$id_tabel = $this->input->post('id_data');
		$this->Model_opsi_kat_berita->delete_data($id_tabel);
		echo "Data berhasil di hapus";
	}
}