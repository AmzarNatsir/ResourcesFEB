<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo base_url();?>assets/dist/img/logo_app/logo-mini.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>Administrator</p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <!--Sub menu Opsi -->
        <li class="header"><b><a href="javascript:void(0)"><i class="fa fa-edit text-red"></i> OPSI</a></b></li>
        <li><a href="<?php echo base_url();?>opsi/kategori_berita"><i class="fa fa-edit"></i> Kategori Berita</a></li>
        <li><a href="<?php echo base_url();?>opsi/kategori_faq"><i class="fa fa-edit"></i> Kategori FAQ</a></li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-edit"></i>
            <span>RPS</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url();?>opsi/aspek_sikap"><i class="fa fa-circle-o"></i> Aspek Sikap</a></li>
            <li><a href="<?php echo base_url();?>opsi/aspek_pengetahuan"><i class="fa fa-circle-o"></i> Aspek Pengetahuan</a></li>
            <li><a href="<?php echo base_url();?>opsi/keterampilan_umum"><i class="fa fa-circle-o"></i> Aspek Keterampilan Umum</a></li>
            <li><a href="<?php echo base_url();?>opsi/keterampilan_khusus"><i class="fa fa-circle-o"></i> Aspek Keterampilan Khusus</a></li>
          </ul>
        </li>
        <!--Sub menu Home Page -->
        <li class="header"><b><a href="javascript:void(0)"><i class="fa fa-home text-red"></i> HOME PAGE</a></b></li>
          <li><a href="<?php echo base_url();?>slide"><i class="fa fa-image"></i> Slides</a></li>
          <li><a href="<?php echo base_url();?>berita"><i class="fa fa-info"></i> Berita</a></li>
          <li><a href="<?php echo base_url();?>mitra"><i class="fa fa-info"></i> Mitra</a></li>
          <li><a href="<?php echo base_url();?>faq"><i class="fa fa-question"></i> FAQ</a></li>
        <!--Sub menu RPS -->
        <li class="header"><b><a href="javascript:void(0)"><i class="fa fa-book text-red"></i> RPS</a></b></li>
          <li class="active"><a href="<?php echo base_url();?>rps/guidelines"><i class="fa fa-book"></i> Guidelines</a></li>
          <li><a href="<?php echo base_url();?>rps/team_teaching"><i class="fa fa-lock"></i> Team Teaching RPS</a></li>
          <li><a href="<?php echo base_url();?>rps"><i class="fa fa-edit"></i> Penyusunan RPS</a></li>
        <!--Sub menu SKPI -->
        <li class="header"><b><a href="javascript:void(0)"><i class="fa fa-book text-red"></i> SKPI</a></b></li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>