<!-- Bootstrap 3.3.7 -->
<script src="<?php echo base_url();?>assets/dist/js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url();?>assets/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url();?>assets/dist/js/demo.js"></script>
<script>
	$(document).ready(function() 
	{
		window.setTimeout(function () { $("#success-alert").alert('close'); }, 2000);
	});
</script>
</body>
</html>